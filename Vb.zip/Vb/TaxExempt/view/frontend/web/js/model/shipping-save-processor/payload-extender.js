/**
 * TaxExempt module
 *
 * @category: PHP
 * @package: Vb/TaxExempt
 * @copyright: Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 * @license: Magento Enterprise Edition (MEE) license
 * @author: Vaibhav Bhalerao <vaibhavbhalerao.15@gmail.com>
 * @keywords: Module Vb_TaxExempt
 */

define([
    'jquery',
    'mage/utils/wrapper'
], function (
    jQuery,
    wrapper
) {
    'use strict';

    return function (processor) {
        return wrapper.wrap(processor, function (proceed, payload) {
            payload = proceed(payload);

            var shippingExtentionAttributes = {
                tax_exemption_number: jQuery('input#tax-exempt-number').val()
            };

            payload.addressInformation.extension_attributes = _.extend(
                payload.addressInformation.extension_attributes,
                shippingExtentionAttributes
            );

            // Remove savecart message from checkout page, when move shipping section to payment section.
            var savecartCheckoutMessage = jQuery('div.savecart-checkout').html();
            if (savecartCheckoutMessage) {
                jQuery('.savecart-checkout').closest(".messages").remove();
            }

            return payload;
        });
    };
});
