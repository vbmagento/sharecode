/**
 * TaxExempt module
 *
 * @category: PHP
 * @package: Vb/TaxExempt
 * @copyright: Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 * @license: Magento Enterprise Edition (MEE) license
 * @author: Vaibhav Bhalerao <vaibhavbhalerao.15@gmail.com>
 * @keywords: Module Vb_TaxExempt
 */

define(
    [
        'ko',
        'jquery',
        'uiComponent'
    ],
    function (ko, $, component) {

        return component.extend({
            defaults: {
                template: 'Vb_TaxExempt/checkout/shipping/tax-exempt'
            },

            taxExemptValue: window.checkoutConfig.shipping.taxexempt.exemption_number,
            isTaxExempted: window.checkoutConfig.shipping.taxexempt.is_tax_exempted,

            isNotSaveCart: function () {
                if (window.location.href.indexOf('is_savecart') > -1) {
                    return false;
                }
                return true;
            }
        });
    }
);

