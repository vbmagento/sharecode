/**
 * TaxExempt module
 *
 * @category: PHP
 * @package: Vb/TaxExempt
 * @copyright: Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 * @license: Magento Enterprise Edition (MEE) license
 * @author: Vaibhav Bhalerao <vaibhavbhalerao.15@gmail.com>
 * @keywords: Module Vb_TaxExempt
 */

define([
    'jquery',
    'underscore',
    'Magento_Ui/js/form/form',
    'ko',
    'mage/translate'
], function (
    $,
    _,
    Component,
    ko,
    $t
) {
    'use strict';

    return function (Component) {
        return Component.extend({
            validateShippingInformation: function () {
                var result = this._super()

                if ($('input:text[name="exemption_number"]').length && $('input:text[name="exemption_number"]') != undefined) {
                    var taxExemptValue = $('input:text[name="exemption_number"]').val();
                    if (taxExemptValue != '') {
                        if (taxExemptValue.length > 20) {
                            this.errorValidationMessage($t('Length should be not more than 20 characters'));
                            return false;
                        }
                    }
                }
                return result;
            }
        });
    }
});
