<?php
/**
 * TaxExempt module
 *
 * @category: PHP
 * @package: Vb/TaxExempt
 * @copyright: Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 * @license: Magento Enterprise Edition (MEE) license
 * @author: Vaibhav Bhalerao <vaibhavbhalerao.15@gmail.com>
 * @keywords: Module Vb_TaxExempt
 */

namespace Vb\TaxExempt\Plugin\Api;

use Magento\Quote\Api\Data\CartExtensionFactory;
use Magento\Quote\Api\Data\CartInterface;
use Magento\Quote\Api\Data\CartSearchResultsInterface;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Framework\Api\SearchResults;

/**
 * Class QuoteRepository
 * @package Vb\TaxExempt\Plugin\Api
 */
class QuoteRepository
{
    /**
     * Cart Extension Attributes Factory
     *
     * @var CartExtensionFactory
     */
    protected $extensionFactory;

    /**
     * QuoteRepository constructor.
     *
     * @param CartExtensionFactory $extensionFactory
     */
    public function __construct(CartExtensionFactory $extensionFactory)
    {
        $this->extensionFactory = $extensionFactory;
    }

    /**
     * Add "tax_exemption_number" extension attribute to cart data object to make it accessible in API data
     *
     * @param CartRepositoryInterface $subject
     * @param CartInterface $cart
     *
     * @return CartInterface
     */
    public function afterGet(CartRepositoryInterface $subject, CartInterface $cart)
    {
        $taxExemptNumber = ($cart->getTaxExemptionNumber()) ?: '';
        /** @var \Magento\Quote\Api\Data\CartInterface $extensionAttributes */
        $extensionAttributes = $cart->getExtensionAttributes();
        $extensionAttributes = $extensionAttributes ? $extensionAttributes : $this->extensionFactory->create();
        $extensionAttributes->setTaxExemptionNumber($taxExemptNumber);
        $cart->setExtensionAttributes($extensionAttributes);

        return $cart;
    }

    /**
     * Add "tax_exemption_number" extension attribute to cart data object to make it accessible in API data
     *
     * @param CartRepositoryInterface $subject
     * @param SearchResults $searchResult
     * @return CartSearchResultsInterface
     */
    public function afterGetList(CartRepositoryInterface $subject, SearchResults $searchResult)
    {
        $carts = $searchResult->getItems();
        /** @var \Magento\Quote\Api\Data\CartInterface $carts */
        foreach ($carts as $cart) {
            $this->afterGet($subject, $cart);
        }
        return $searchResult;
    }
}
