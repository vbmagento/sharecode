<?php
/**
 * TaxExempt module
 *
 * @category: PHP
 * @package: Vb/TaxExempt
 * @copyright: Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 * @license: Magento Enterprise Edition (MEE) license
 * @author: Vaibhav Bhalerao <vaibhavbhalerao.15@gmail.com>
 * @keywords: Module Vb_TaxExempt
 */

namespace Vb\TaxExempt\Plugin\Api;

use Magento\Sales\Api\Data\ShipmentExtensionFactory;
use Magento\Sales\Api\Data\ShipmentInterface;
use Magento\Sales\Api\ShipmentRepositoryInterface;
use \Magento\Sales\Api\Data\ShipmentSearchResultInterface;

/**
 * Class ShipmentRepository
 * @package Vb\TaxExempt\Plugin\Api
 */
class ShipmentRepository
{
    /**
     * @var ShipmentExtensionFactory
     */
    private $extensionFactory;

    /**
     * ShipmentRepository constructor.
     *
     * @param ShipmentExtensionFactory $extensionFactory
     */
    public function __construct(ShipmentExtensionFactory $extensionFactory)
    {
        $this->extensionFactory = $extensionFactory;
    }

    /**
     * @param ShipmentRepositoryInterface $subject
     * @param ShipmentInterface $shipment
     * @return ShipmentInterface
     */
    public function afterGet(
        ShipmentRepositoryInterface $subject,
        ShipmentInterface $shipment
    ) {
        /** @var \Magento\Sales\Api\Data\ShipmentExtensionInterface $extensionAttributes */
        $extensionAttributes = $shipment->getExtensionAttributes();
        if ($extensionAttributes === null) {
            $extensionAttributes = $this->extensionFactory->create();
        }
        $order = $shipment->getOrder();
        $taxExemptNumber = ($order->getTaxExemptionNumber()) ?: '';
        $extensionAttributes->setTaxExemptionNumber($taxExemptNumber);
        $shipment->setExtensionAttributes($extensionAttributes);
        return $shipment;
    }

    /**
     * @param ShipmentRepositoryInterface $subject
     * @param ShipmentSearchResultInterface $searchResult
     * @return ShipmentSearchResultInterface
     */
    public function afterGetList(
        ShipmentRepositoryInterface $subject,
        ShipmentSearchResultInterface $searchResult
    ) {
        $shipments = $searchResult->getItems();
        /** @var \Magento\Sales\Api\Data\ShipmentInterface $shipment */
        foreach ($shipments as $shipment) {
            $this->afterGet($subject, $shipment);
        }
        return $searchResult;
    }
}
