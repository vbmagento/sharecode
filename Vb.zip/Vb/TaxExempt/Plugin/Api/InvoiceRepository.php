<?php
/**
 * TaxExempt module
 *
 * @category: PHP
 * @package: Vb/TaxExempt
 * @copyright: Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 * @license: Magento Enterprise Edition (MEE) license
 * @author: Vaibhav Bhalerao <vaibhavbhalerao.15@gmail.com>
 * @keywords: Module Vb_TaxExempt
 */

namespace Vb\TaxExempt\Plugin\Api;

use Magento\Sales\Api\Data\InvoiceExtensionFactory;
use Magento\Sales\Api\Data\InvoiceInterface;
use Magento\Sales\Api\InvoiceRepositoryInterface;
use Magento\Sales\Api\Data\InvoiceSearchResultInterface;

/**
 * Class InvoiceRepository
 * @package Vb\TaxExempt\Plugin\Api
 */
class InvoiceRepository
{
    /**
     * @var InvoiceExtensionFactory
     */
    private $extensionFactory;

    /**
     * InvoiceRepository constructor.
     *
     * @param InvoiceExtensionFactory $extensionFactory
     */
    public function __construct(
        InvoiceExtensionFactory $extensionFactory
    ) {
        $this->extensionFactory = $extensionFactory;
    }

    /**
     * @param InvoiceRepositoryInterface $subject
     * @param InvoiceInterface $invoice
     * @return InvoiceInterface
     */
    public function afterGet(
        InvoiceRepositoryInterface $subject,
        InvoiceInterface $invoice
    ) {
        /** @var \Magento\Sales\Api\Data\InvoiceExtensionInterface $extensionAttributes */
        $extensionAttributes = $invoice->getExtensionAttributes();
        if ($extensionAttributes === null) {
            $extensionAttributes = $this->extensionFactory->create();
        }
        $order = $invoice->getOrder();
        $taxExemptNumber = ($order->getTaxExemptionNumber()) ?: '';

        $extensionAttributes->setTaxExemptionNumber($taxExemptNumber);
        $invoice->setExtensionAttributes($extensionAttributes);

        return $invoice;
    }

    /**
     * @param InvoiceRepositoryInterface $subject
     * @param InvoiceSearchResultInterface $searchResult
     * @return InvoiceSearchResultInterface
     */
    public function afterGetList(
        InvoiceRepositoryInterface $subject,
        InvoiceSearchResultInterface $searchResult
    ) {
        $invoices = $searchResult->getItems();
        /** @var \Magento\Sales\Api\Data\InvoiceInterface $inovice */
        foreach ($invoices as $invoice) {
            $this->afterGet($subject, $invoice);
        }
        return $searchResult;
    }
}
