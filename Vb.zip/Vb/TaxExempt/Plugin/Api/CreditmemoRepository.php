<?php
/**
 * TaxExempt module
 *
 * @category: PHP
 * @package: Vb/TaxExempt
 * @copyright: Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 * @license: Magento Enterprise Edition (MEE) license
 * @author: Vaibhav Bhalerao <vaibhavbhalerao.15@gmail.com>
 * @keywords: Module Vb_TaxExempt
 */

namespace Vb\TaxExempt\Plugin\Api;

use Magento\Sales\Api\Data\CreditmemoExtensionFactory;
use Magento\Sales\Api\Data\CreditmemoInterface;
use Magento\Sales\Api\CreditmemoRepositoryInterface;
use \Magento\Sales\Api\Data\CreditmemoSearchResultInterface;

/**
 * Class CreditmemoRepository
 * @package Vb\TaxExempt\Plugin\Api
 */
class CreditmemoRepository
{
    /**
     * @var CreditmemoExtensionFactory
     */
    private $extensionFactory;

    /**
     * CreditmemoRepository constructor.
     *
     * @param CreditmemoExtensionFactory $extensionFactory
     */
    public function __construct(CreditmemoExtensionFactory $extensionFactory)
    {
        $this->extensionFactory = $extensionFactory;
    }

    /**
     * @param CreditmemoRepositoryInterface $subject
     * @param CreditmemoInterface $creditmemo
     * @return CreditmemoInterface
     */
    public function afterGet(
        CreditmemoRepositoryInterface $subject,
        CreditmemoInterface $creditmemo
    ) {
        /** @var \Magento\Sales\Api\Data\CreditmemoExtensionInterface $extensionAttributes */
        $extensionAttributes = $creditmemo->getExtensionAttributes();
        if ($extensionAttributes === null) {
            $extensionAttributes = $this->extensionFactory->create();
        }
        $order = $creditmemo->getOrder();
        $taxExemptNumber = ($order->getTaxExemptionNumber()) ?: '';
        $extensionAttributes->setTaxExemptionNumber($taxExemptNumber);
        $creditmemo->setExtensionAttributes($extensionAttributes);
        return $creditmemo;
    }

    /**
     * @param CreditmemoRepositoryInterface $subject
     * @param CreditmemoSearchResultInterface $searchResult
     * @return CreditmemoSearchResultInterface
     */
    public function afterGetList(
        CreditmemoRepositoryInterface $subject,
        CreditmemoSearchResultInterface $searchResult
    ) {
        $creditmemos = $searchResult->getItems();
        /** @var \Magento\Sales\Api\Data\CreditmemoInterface $creditmemo */
        foreach ($creditmemos as $creditmemo) {
            $this->afterGet($subject, $creditmemo);
        }
        return $searchResult;
    }
}
