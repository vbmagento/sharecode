<?php
/**
 * TaxExempt module
 *
 * @category: PHP
 * @package: Vb/TaxExempt
 * @copyright: Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 * @license: Magento Enterprise Edition (MEE) license
 * @author: Vaibhav Bhalerao <vaibhavbhalerao.15@gmail.com>
 * @keywords: Module Vb_TaxExempt
 */

namespace Vb\TaxExempt\Plugin;

use Magento\Tax\Model\Sales\Total\Quote\CommonTaxCollector;

/**
 * Class CommonTaxCollectorPlugin
 * @package Vb\TaxExempt\Plugin
 */
class CommonTaxCollectorPlugin
{
    /**
     * Plugin to set tax against row items
     *
     * @param CommonTaxCollector $subject
     * @param $result
     * @param $quoteItem
     * @param $itemTaxDetails
     * @param $baseItemTaxDetails
     * @return mixed
     */
    public function afterUpdateItemTaxInfo(
        CommonTaxCollector $subject,
        $result,
        $quoteItem,
        $itemTaxDetails,
        $baseItemTaxDetails
    ) {
        // If quote has tax exempt number, then set tax as zero against row items
        if ($quoteItem->getQuote()->getTaxExemptionNumber()) {
            $quoteItem->setPriceInclTax($itemTaxDetails->getPrice());
            $quoteItem->setRowTotalInclTax($itemTaxDetails->getRowTotal());
            $quoteItem->setTaxAmount(0);
            $quoteItem->setTaxPercent(0);

            $quoteItem->setBasePriceInclTax($baseItemTaxDetails->getPrice());
            $quoteItem->setBaseRowTotalInclTax($baseItemTaxDetails->getRowTotal());
            $quoteItem->setBaseTaxAmount(0);
        }
        return $result;
    }
}
