<?php
/**
 * TaxExempt module
 *
 * @category: PHP
 * @package: Vb/TaxExempt
 * @copyright: Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 * @license: Magento Enterprise Edition (MEE) license
 * @author: Vaibhav Bhalerao <vaibhavbhalerao.15@gmail.com>
 * @keywords: Module Vb_TaxExempt
 */

namespace Vb\TaxExempt\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;

class ConvertCustomFieldsFromQuoteToOrder implements ObserverInterface
{
    /**
     * Convert tax exempt number from quote to order table
     *
     * @param Observer $observer
     * @return $this
     */
    public function execute(Observer $observer)
    {
        $observer->getEvent()->getOrder()->setTaxExemptionNumber(
            $observer->getEvent()->getQuote()->getTaxExemptionNumber()
        );
        return $this;
    }
}
