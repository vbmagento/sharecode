<?php
/**
 * TaxExempt module
 *
 * @category: PHP
 * @package: Vb/TaxExempt
 * @copyright: Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 * @license: Magento Enterprise Edition (MEE) license
 * @author: Vaibhav Bhalerao <vaibhavbhalerao.15@gmail.com>
 * @keywords: Module Vb_TaxExempt
 */

namespace Vb\TaxExempt\Observer;

use Magento\Framework\View\Element\Template;
use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;

/**
 * Class BlockObserver
 * @package Vb\ShippingRate\Observer\Adminhtml
 */
class BlockObserver implements ObserverInterface
{
    /**
     * @var Template
     */
    protected $coreTemplate;

    /**
     * BlockObserver constructor.
     * @param Template $coreTemplate
     */
    public function __construct(
        Template $coreTemplate
    ) {
        $this->coreTemplate = $coreTemplate;
    }

    /**
     * @param EventObserver $observer
     * @return $this|void
     */
    public function execute(EventObserver $observer)
    {
        // Set element section to update tax exemption number
        $elementArray = [
            'sales.order.info',
            'sales.order.creditmemo',
            'sales.order.print.info',
            'sales.order.print.invoice',
            'sales.order.print.shipment',
            'sales.order.print.creditmemo'
        ];

        if (in_array($observer->getElementName(), $elementArray)) {
            $elementBlock = $observer->getLayout()->getBlock($observer->getElementName());
            $order = $elementBlock->getOrder();
            if (!$order->getTaxExemptionNumber()) {
                return $this;
            }
            $pickupInfo = $this->coreTemplate
                ->setTaxExemptionNumber($order->getTaxExemptionNumber())
                ->setTemplate('Vb_TaxExempt::order/view/tax-exemption-number.phtml')
                ->toHtml();
            $html = $observer->getTransport()->getOutput() . $pickupInfo;
            $observer->getTransport()->setOutput($html);
        }
        return $this;
    }
}
