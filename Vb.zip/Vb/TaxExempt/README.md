Vb\TaxExempt module provides custom implementation for following features.
- To display Tax Exempt field on checkout page below shipping methods
- Apply validation on tax exempt field on checkout page
- Provide tax exempt to customer i.e. tax will be zero on order, when customer apply tax exempt number on checkout page
- Save tax exempt number value in quote and order tables
- Display tax exempt number in order, invoice, creditmemo, shipment
- Display tax exempt number on order history detail page in admin as well as on front-end
- Show tax exempt field and it's value in all require api
