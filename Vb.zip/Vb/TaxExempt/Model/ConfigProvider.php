<?php
/**
 * TaxExempt module
 *
 * @category: PHP
 * @package: Vb/TaxExempt
 * @copyright: Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 * @license: Magento Enterprise Edition (MEE) license
 * @author: Vaibhav Bhalerao <vaibhavbhalerao.15@gmail.com>
 * @keywords: Module Vb_TaxExempt
 */

namespace Vb\TaxExempt\Model;

use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Quote\Api\CartRepositoryInterface;
use Psr\Log\LoggerInterface;

/**
 * Class ConfigProvider
 * @package Vb\TaxExempt\Model
 */
class ConfigProvider implements ConfigProviderInterface
{
    /**
     * @var CustomerSession
     */
    protected $customerSession;

    /**
     * @var CheckoutSession
     */
    protected $checkoutSession;

    /**
     * @var CustomerRepositoryInterface
     */
    protected $customerRepositoryInterface;

    /**
     * @var CartRepositoryInterface
     */
    protected $quote;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * ConfigProvider constructor.
     *
     * @param CustomerSession $customerSession
     * @param CheckoutSession $checkoutSession
     * @param CustomerRepositoryInterface $customerRepositoryInterface
     * @param CartRepositoryInterface $quote
     * @param LoggerInterface $logger
     */
    public function __construct(
        CustomerSession $customerSession,
        CheckoutSession $checkoutSession,
        CustomerRepositoryInterface $customerRepositoryInterface,
        CartRepositoryInterface $quote,
        LoggerInterface $logger
    ) {
        $this->customerSession = $customerSession;
        $this->checkoutSession = $checkoutSession;
        $this->customerRepositoryInterface = $customerRepositoryInterface;
        $this->quote = $quote;
        $this->logger = $logger;
    }

    /**
     * This method is responsible to set tax exempt number in config
     *
     * @return array
     */
    public function getConfig()
    {
        $taxExemptNumber = '';
        $isTaxExempted = 0;
        try {
            if ($this->customerSession->getId()) {
                $customerObj = $this->customerRepositoryInterface->getById($this->customerSession->getId());
                $isTaxExempted = $customerObj->getCustomAttribute('is_tax_exempted')->getValue();

                if ($this->checkoutSession->getQuote()->getId()) {
                    // Check tax exempt number is exists in quote, if not than check against customer
                    $quote = $this->quote->getActive($this->checkoutSession->getQuote()->getId());
                    if ($quote->getTaxExemptionNumber()) {
                        $taxExemptNumber = $quote->getTaxExemptionNumber();
                    } else {
                        if ($customerObj->getCustomAttribute('exemption_number') && $isTaxExempted) {
                            $taxExemptNumber = $customerObj->getCustomAttribute('exemption_number')->getValue();
                        }
                    }
                }
            }
        }  catch (\Exception $e) {
            $this->logger->info($e->getMessage());
        }

        // Prepare config array
        $config = [
            'shipping' => [
                'taxexempt' => [
                    'exemption_number' => $taxExemptNumber,
                    'is_tax_exempted' => $isTaxExempted
                ],
            ]
        ];
        return $config;
    }
}
