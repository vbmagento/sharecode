<?php
/**
 * TaxExempt module
 *
 * @category: PHP
 * @package: Vb/TaxExempt
 * @copyright: Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 * @license: Magento Enterprise Edition (MEE) license
 * @author: Vaibhav Bhalerao <vaibhavbhalerao.15@gmail.com>
 * @keywords: Module Vb_TaxExempt
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Vb_TaxExempt',
    __DIR__
);
